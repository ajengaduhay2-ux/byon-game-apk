# BYON Game Android WebView

A minimal Android Studio project that opens https://byongame.web.id/ in a fullscreen landscape WebView. The game remains hosted online; an internet connection is required.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

This is an unofficial wrapper and is not affiliated with the website owner. Use only if you have permission to package the site.
